FDF=importdata('flow-df-relation.dat');
for i=1:7
    plot(FDF{i}(:,1),FDF{i}(:,2),'.')
hold on
end
edges=[0:0.1:1.3];
FDF_all=[FDF{1};FDF{2};FDF{3};FDF{4};FDF{5};FDF{6};FDF{7}];
c=FDF_all(:,1);
d=FDF_all(:,2);
[n,bin]=histc(c,edges);
cy=cell(1,size(edges,2)-1);cx=cell(1,size(edges,2)-1);cyjam=cell(1,size(edges,2)-1);cyfree=cell(1,size(edges,2)-1);
meay=zeros(1,size(edges,2)-1);sty=zeros(1,size(edges,2)-1);
meax=zeros(1,size(edges,2)-1);stx=zeros(1,size(edges,2)-1);
fi0=zeros(1,size(edges,2)-1);
Fi0=zeros(1,size(edges,2)-1);
for i=1:size(edges,2)-1
    lix=c;liy=d;
    cx{i}=lix(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    cy{i}=liy(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    meay(i)=mean(cy{i});sty(i)=std(cy{i});
    meax(i)=mean(cx{i});stx(i)=std(cx{i});
end
hold on
errorbar(meax,meay,sty)
set(gcf,'windowstyle','normal')