HSR=importdata('headway-span-relation.dat');
for i=1:7
    plot(HSR{i}(:,1),HSR{i}(:,2),'.')
hold on
end
edges=[0.25:0.15:4.6];
FDF_all=[HSR{1};HSR{2};HSR{3};HSR{4};HSR{5};HSR{6};HSR{7}];
c=FDF_all(:,1);
d=FDF_all(:,2);
[n,bin]=histc(c,edges);
cy=cell(1,size(edges,2)-1);cx=cell(1,size(edges,2)-1);cyjam=cell(1,size(edges,2)-1);cyfree=cell(1,size(edges,2)-1);
meay=zeros(1,size(edges,2)-1);sty=zeros(1,size(edges,2)-1);
meax=zeros(1,size(edges,2)-1);stx=zeros(1,size(edges,2)-1);
fi0=zeros(1,size(edges,2)-1);
Fi0=zeros(1,size(edges,2)-1);
for i=1:size(edges,2)-1
    lix=c;liy=d;
    cx{i}=lix(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    cy{i}=liy(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    meay(i)=mean(cy{i});sty(i)=std(cy{i});
    meax(i)=mean(cx{i});stx(i)=std(cx{i});
end
hold on
errorbar(meax,meay,sty)
set(gcf,'windowstyle','normal')