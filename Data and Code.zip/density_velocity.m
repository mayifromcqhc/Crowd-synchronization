DVR=importdata('density-velocity-relation.dat');
for i=1:7
    plot(DVR{i}(:,1),DVR{i}(:,2),'.')
hold on
end
edges=[0.25:0.15:4];
FDF_all=[DVR{1};DVR{2};DVR{3};DVR{4};DVR{5};DVR{6};DVR{7}];
c=FDF_all(:,1);
d=FDF_all(:,2);
[n,bin]=histc(c,edges);
cy=cell(1,size(edges,2)-1);cx=cell(1,size(edges,2)-1);cyjam=cell(1,size(edges,2)-1);cyfree=cell(1,size(edges,2)-1);
meay=zeros(1,size(edges,2)-1);sty=zeros(1,size(edges,2)-1);
meax=zeros(1,size(edges,2)-1);stx=zeros(1,size(edges,2)-1);
fi0=zeros(1,size(edges,2)-1);
Fi0=zeros(1,size(edges,2)-1);
for i=1:size(edges,2)-1
    lix=c;liy=d;
    cx{i}=lix(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    cy{i}=liy(find(bin==i));%b(:,4)Ϊ����3ΪƵ��5Ϊ����
    meay(i)=mean(cy{i});sty(i)=std(cy{i});
    meax(i)=mean(cx{i});stx(i)=std(cx{i});
end
hold on
errorbar(meax,meay,sty)
set(gcf,'windowstyle','normal')